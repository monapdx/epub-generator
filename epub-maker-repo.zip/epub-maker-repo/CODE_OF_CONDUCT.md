# Code of Conduct

We follow the [Contributor Covenant v2.1](https://www.contributor-covenant.org/version/2/1/code_of_conduct/).

Instances of abusive, harassing, or otherwise unacceptable behavior may be reported by opening an issue or emailing the maintainer.
